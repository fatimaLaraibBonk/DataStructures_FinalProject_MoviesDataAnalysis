//graph file
#include <string>
#include "movie_node.h"
#include "hash.h"
#include <ctime>
//each movie acts as a vertex 
//edges are created between movies that share at least one character or genre
//movie nodes already have a linked list of genres and actors;

class Graph {
	//using adjacency list
	//an adacency matrix would take too much memory 
	int capacity; //total number of nodes/vertices that can be added
	int size; //actual number of vertices add into the graph
	movieNode** adj;
public:
	Graph() {
		cout << "\033[32mCreating graph...\033[0m" << endl;
		capacity = 5100;
		size = 0;
		adj = new movieNode * [capacity]();
		for (int i = 0; i < capacity; i++) {
			//setting these connections to null
			adj[i] = nullptr;
		}
	}
	void addVertex(movieNode* movie) {
		//this function recieves a movie node and makes a vertex 
		//cout << "Adding node in graph..." << endl;
		adj[size++] = movie;
		//cout << "Node added!" << endl;
		//cout << "Total size: " << size << endl;
	}
	int verticesShareActor(movieNode* m1, movieNode* m2) {
		//returns how many actors are being shared 
		int sharedActorsCount = 0;
		//every movie has 3 actors so 
		node* temp1 = m1->actorsList.getHead();
		node* temp2 = m2->actorsList.getHead();
		do {
			temp2 = m2->actorsList.getHead();
			do {
				if (temp1->getData() == temp2->getData()) sharedActorsCount++;
				temp2 = temp2->getNext();
			} while (temp2 != m2->actorsList.getHead());
			temp1 = temp1->getNext();

		} while (temp1 != m1->actorsList.getHead());

		// cout << "Shared Actors: " << sharedActorsCount << endl;
		return sharedActorsCount;
	}
	int verticesShareGenre(movieNode* m1, movieNode* m2) {
		//returns how many genres are being shared
		int genresSharedCount = 0;
		//same logic as above
		//we can use hash but time complexity is almost the same
		node* temp1 = m1->genresList.getHead();
		node* temp2 = m2->genresList.getHead();
		do {
			temp2 = m2->genresList.getHead();
			do {
				if (temp1->getData() == temp2->getData()) genresSharedCount++;
				temp2 = temp2->getNext();
			} while (temp2 != m2->genresList.getHead());
			temp1 = temp1->getNext();

		} while (temp1 != m1->genresList.getHead());
		//cout << "Shared genres: " << genresSharedCount << endl;
		return genresSharedCount;
	}

	//we can create a function that uses a formula to calculate the weight
	//those who share more->are closer
	//those who share less->are father
	float calculateWeight(movieNode* m1, movieNode* m2) {
		//our our own edge formula
		int genresSharedCount = verticesShareGenre(m1, m2);
		int sharedActorsCount = verticesShareActor(m1, m2);
		float similarityScore = 0.5 * sharedActorsCount + 0.5 * genresSharedCount;
		float weight = 1 / (1 + similarityScore);
		//cout << "Weight: " << weight << endl;
		return weight;
	}

	void addEdge(movieNode* from, movieNode* to, float weight) {
		//check if edge already exists - DON'T add duplicates
		edge* newEdge = new edge(to, weight);
		newEdge->next = from->edges;
		from->edges = newEdge;
	}

	int findMovieIndex(const string& name, int* nameToIndex, string* indexToName, bool* slotUsed, int mapSize) {
		int hash = hashString(name);
		int slot = hash % mapSize;
		int startSlot = slot;
		while (slotUsed[slot]) {
			if (indexToName[slot] == name) {
				return nameToIndex[slot];
			}
			slot = (slot + 1) % mapSize;
			if (slot == startSlot){
				break;//wrapping around 
			}
		}
		return -1;
	}

	//collects movie by traversing tree
	void collectMovieNames(movieNode* root, movieNode* exclude, string* names, int& count, int maxCount) {
		if (!root || count >= maxCount) return;
		//quick stack 
		movieNode* stack[500];
		int stackTop = 0;
		movieNode* current = root;
		//like a simple arrayy typa stack 
		while ((current != nullptr || stackTop > 0) && count < maxCount) {
			while (current != nullptr && stackTop < 500) {
				stack[stackTop++] = current;
				current = current->left;
			}
			if (stackTop > 0) {
				//pre :PPP
				current = stack[--stackTop];
				if (current != exclude && current->movieName != exclude->movieName) {
					names[count++] = current->movieName;
				}
				current = current->right;
			}
		}
	}
	
	int hashString(const string& str) {
		//hash funcion for string 
		//helps with O1 basically each movie name gets like an index 
		int hash = 0;
		for (int i = 0; i < str.length(); i++) {
			hash = hash * 31 + str[i];
			if (hash < 0) hash = -hash;
		}
		return hash;
	}
	//we pass our hash tables as parametrs
	//one of them contains like the hash for actors and one contains the hash for genres 
	void createEdges(hashTableForActors& hashTabA, hashTableForGenres& hashTabG) {
		clock_t startTime = clock(); //ust for time measuring 
		cout << "Building connections..." << endl;
		
		//creating a map
		//our original approach used like matchign using hash functions which took us to On2 complexity 
		int mapSize = size * 2; //lessens the number if collisions 
		//creating 3 parallel arrats to store their name, index and the fact if they were used or not 
		int* nameToIndex = new int[mapSize];
		string* indexToName = new string[mapSize];
		bool* slotUsed = new bool[mapSize];
		
		//initializing values
		//slots used false etc 
		//like we do for djastraka 
		for (int i = 0; i < mapSize; i++) {
			nameToIndex[i] = -1;
			slotUsed[i] = false;
		}
		
		//NOW WE FINALLLY FILLIT BEUH 
		//Its like a quick hash function
		//size cuz thast the actuall number of nodes we have
		///but we have greater spaces to prevent collision 
		for (int i = 0; i < size; i++) {
			//get name for node 
			string name = adj[i]->movieName;
			//get hash value 
			int hash = hashString(name);
			//get actual slot or where its gonna be placed 
			int slot = hash % mapSize;
			
			//linear probing if collisions keep happenign 
			while (slotUsed[slot] && indexToName[slot] != name) {
				slot = (slot + 1) % mapSize;
			}
			//if not used put that shit in there 
			if (!slotUsed[slot]) {
				slotUsed[slot] = true;
				indexToName[slot] = name;
				nameToIndex[slot] = i;
			}
		}
		//now ere don eith that 
		//our look up for thingd is practically O1
		//initialziign for edge added 
		bool** edgeAdded = new bool*[size];
		for (int i = 0; i < size; i++) {
			edgeAdded[i] = new bool[size];
			for (int j = 0; j < size; j++) {
				edgeAdded[i][j] = false;
			}
		}
		//temporary array to store strings 
		string* tempNames = new string[5100];
		//now we actually go into the meat of the code 
		for (int i = 0; i < size; i++) { //linear 
			if (i % 100 == 0) {
				cout << "\033[35mEdges created : " << i << "/" << size << "\033[0m" << endl;
			}
			movieNode* currentMovie = adj[i];
			//okay so we go one by one 
			//we take the the currnt movie 
			// process actors and get all movies sharing actors for each movie
			node* actorNode = currentMovie->actorsList.getHead();
			do {
				string actorName = actorNode->getData(); //grab the data for the current movie
				moviesTree moviesOfActor = hashTabA.getMoviesForKey(actorName);
				movieNode* treeRoot = moviesOfActor.getHead();
				//so we grab the name of the actor, the movies of the actor, and the head of the moviestREE
				int nameCount = 0;
				//all movies of that actor but in an array 
				collectMovieNames(treeRoot, currentMovie, tempNames, nameCount, 5000);
				//WE GRAB the names of the movies 
				//it update sthe temowe made before 
				for (int k = 0; k < nameCount; k++) {
					int otherIdx = findMovieIndex(tempNames[k], nameToIndex, indexToName, slotUsed, mapSize);
					//now we have the names of the movies we can create connections
					if (otherIdx != -1 && otherIdx != i && !edgeAdded[i][otherIdx]) {
						edgeAdded[i][otherIdx] = true;
						edgeAdded[otherIdx][i] = true;
						//we also nned to add weight
						//so we use our oen forumal
						float w = calculateWeight(currentMovie, adj[otherIdx]);
						if (w < 1) {
							//bidirectional
							//cuz id tangled is similar to frizen 
							//then frozen is also similat to tangled 
							addEdge(currentMovie, adj[otherIdx], w);
							addEdge(adj[otherIdx], currentMovie, w);
						}
					}
				}
				//for shared actors 
				actorNode = actorNode->getNext();
			} while (actorNode != currentMovie->actorsList.getHead());

			// process genres to get all movies sharing genres
			node* genreNode = currentMovie->genresList.getHead();
			do {
				string genreName = genreNode->getData();
				moviesTree genresOfMovie = hashTabG.getMoviesForKey(genreName);
				movieNode* treeRoot = genresOfMovie.getHead();
				//same logic as above
				int nameCount = 0;
				collectMovieNames(treeRoot, currentMovie, tempNames, nameCount, 5000);
				for (int k = 0; k < nameCount; k++) {
					int otherIdx = findMovieIndex(tempNames[k], nameToIndex, indexToName, slotUsed, mapSize);
					if (otherIdx != -1 && otherIdx != i && !edgeAdded[i][otherIdx]) {
						edgeAdded[i][otherIdx] = true;
						edgeAdded[otherIdx][i] = true;
						float w = calculateWeight(currentMovie, adj[otherIdx]);
						if (w < 1) {
							//preverys from repeating connections 
							addEdge(currentMovie, adj[otherIdx], w);
							addEdge(adj[otherIdx], currentMovie, w);
						}
					}
				}
				//for shared generes 
				genreNode = genreNode->getNext();
			} while (genreNode != currentMovie->genresList.getHead());
		}
		//making sure to cleaning up all memory 
		//clean up crew ahh
		delete[] tempNames;
		delete[] nameToIndex;
		delete[] indexToName;
		delete[] slotUsed;
		for (int i = 0; i < size; i++) {
			delete[] edgeAdded[i];
		}
		delete[] edgeAdded;
		clock_t endTime = clock();
		//these emojis dont work on my computer but they work  on huzaifas computer 
		double timeTaken = ((double)(endTime - startTime)) / CLOCKS_PER_SEC;
		cout << "Connections created!" << endl;
		cout << "⏱️  Edge creation completed in " << timeTaken << " seconds" << endl;
	}

	bool edgeExists(movieNode* from, movieNode* to) {
		//this function prevents us from  reconnectitng the same edges
		edge* e = from->edges;
		while (e != nullptr) {
			if (e->connectedMovie == to) {
				return true;
			}
			e = e->next;
		}
		return false;
	}
	void findShortestPath(string source, string target) {
		cout << "Finding shortest apath: " << endl;
		cout << "From: '" << source << "'" << endl;
		cout << "To: '" << target << "'" << endl;
		//movies are already lowercase from CSV cleaning, and input is converted in main.cpp
		//so like this 
		movieNode* sourceMovie = nullptr;
		for (int i = 0; i < size; i++) {
			if (adj[i]->movieName == source) {
				sourceMovie = adj[i];
				cout << "Source movie found at index " << i << endl;
				break;
			}
		}
		if (!sourceMovie) {
			cout << "Source movie '" << source << "' not found in database!" << endl;
			return;
		}
		movieNode* targetMovie = nullptr;
		for (int i = 0; i < size; i++) {
			//is it On yeah butwere low on time here 
			if (adj[i]->movieName == target) {
				targetMovie = adj[i];
				cout << "Target movie found at index " << i << endl;
				break;
			}
		}
		if (!targetMovie) {
			//if taegrt movie doesnt exist 
			cout << "Target movie '" << target << "' not found in database!" << endl;
			return;
		}
		int edgeCount = 0;
		edge* e = sourceMovie->edges;
		while (e) {
			edgeCount++;
			e = e->next;
		}
		cout << "Source movie has " << edgeCount << " connections" << endl;
		edgeCount = 0;
		e = targetMovie->edges;
		while (e) {
			edgeCount++;
			e = e->next;
		}
		cout << "Target movie has " << edgeCount << " connections" << endl;
		dijkstra(sourceMovie, targetMovie); //to help find the shortest path 
	}

	void dijkstra(movieNode* source, movieNode* target) {
		//thisislike normal djastka 
		float* dist = new float[size];
		bool* visited = new bool[size];
		int* parent = new int[size];

		//initializing value  s
		for (int i = 0; i < size; i++) {
			dist[i] = 999999.0f; //infinte distance 
			visited[i] = false; //not visited 
			parent[i] = -1;
		}
		int sourceIdx = -1;
		int targetIdx = -1;
		for (int i = 0; i < size; i++) {
			if (adj[i] == source) sourceIdx = i;
			if (adj[i] == target) targetIdx = i;
		}
		if (sourceIdx == -1 || targetIdx == -1) {
			cout << "Could not find movie indices!" << endl;
			delete[] dist;
			delete[] visited;
			delete[] parent;
			return;
		}
		cout << "Source index: " << sourceIdx << ", Target index: " << targetIdx << endl;
		dist[sourceIdx] = 0;
		int iterations = 0;
		for (int i = 0; i < size; i++) {
			iterations++;
			int u = -1;
			float shortest = 999999.0f;
			for (int j = 0; j < size; j++) {
				if (!visited[j] && dist[j] < shortest) {
					shortest = dist[j];
					u = j;
				}
			}
			if (u == -1) {
				cout << "No more reachable nodes. Stopped at iteration " << iterations << endl;
				break;
			}
			visited[u] = true;
			if (u == targetIdx) {
				cout << "Target reached at iteration " << iterations << endl;
				break;
			}
			//if (iterations % 500 == 0) { //debugging output
			//	cout << "Iteration " << iterations << "..." << endl;
			//}
			edge* e = adj[u]->edges;
			while (e != nullptr) {
				int v = -1;
				for (int k = 0; k < size; k++) {
					if (adj[k] == e->connectedMovie) {
						v = k;
						break;
					}
				}

				if (v != -1 && !visited[v]) {
					float newDist = dist[u] + e->weight;
					if (newDist < dist[v]) {
						dist[v] = newDist;
						parent[v] = u;
					}
				}
				e = e->next;
			}
		}

		cout << "Shortest path algo completed!" << endl;
		if (dist[targetIdx] >= 999999.0f) {
			cout << "No path exists >.<" << endl;
			delete[] dist;
			delete[] visited;
			delete[] parent;
			return;
		}
		//else path has been fiund 
		cout << "Path found!" << endl;
		cout << "Total distance: " << fixed << dist[targetIdx] << endl;
		//displayign path 
		int path[5100];
		int count = 0;
		int cur = targetIdx;
		while (cur != -1) {
			path[count++] = cur;
			cur = parent[cur];
		}
		cout << "\nPath (" << count << " movies):" << endl;
		for (int i = count - 1; i >= 0; i--) {
			cout << (count - i) << ". " << adj[path[i]]->movieName;

			if (i != 0) {
				edge* e = adj[path[i]]->edges;
				while (e) {
					if (e->connectedMovie == adj[path[i - 1]]) {
						cout << " [" << fixed << e->weight << "] ";
						break;
					}
					e = e->next;
				}
			}
			cout << endl;
		}
		delete[] dist;
		delete[] visited;
		delete[] parent;
	}

	struct Candidate {
		movieNode* movie;
		double weight;
		double rating;
	};

	void getRecommendations(const string& movieName, ratingTree& rt) {
		//our recommendations logic is such that
		//we prefers movies with greater similarity or less weight 
		//and that si calulcated from our formula
		//then we also need movies iwth actual good ratings
		movieNode* movie = nullptr;
		//cheakcking if the movies actually exist in the database 
		//if they dontwe return 
		for (int i = 0; i < size; i++) {
			if (adj[i]->movieName == movieName) {
				movie = adj[i];
				break;
			}
		}
		if (!movie) {
			cout << "Movie not found in database!" << endl;
			return;
		}
		//if it does exist in our database then we can go ahead and find our recommendations
		int edgeCount = 0;
		edge* e = movie->edges;
		while (e) {
			edgeCount++;
			e = e->next;
		}
		if (edgeCount == 0) {
			cout << "No recommendations available for this movie." << endl;
			return;
		}
		//candidates are basically movies that can be recommendded 
		Candidate* candidates = new Candidate[edgeCount];
		e = movie->edges;
		int index = 0;
		while (e) {
			candidates[index].movie = e->connectedMovie;
			candidates[index].weight = e->weight;
			candidates[index].rating = e->connectedMovie->rating;
			index++;
			e = e->next;
		}
		for (int i = 0; i < edgeCount - 1; i++) {
			for (int j = 0; j < edgeCount - i - 1; j++) {
				bool shouldSwap = false;
				if (candidates[j].weight > candidates[j + 1].weight) {
					shouldSwap = true;
				}
				else if (candidates[j].weight == candidates[j + 1].weight) {
					if (candidates[j].rating < candidates[j + 1].rating) {
						shouldSwap = true;
					}
				}

				if (shouldSwap) {
					Candidate temp = candidates[j];
					candidates[j] = candidates[j + 1];
					candidates[j + 1] = temp;
				}
			}
		}
		cout << "Top 5 Recommended Movies:" << endl;
		int count = (edgeCount < 5) ? edgeCount : 5;
		for (int i = 0; i < count; i++) {
			cout << (i + 1) << ". " << candidates[i].movie->movieName
				<< " (Similarity: " << (100 - candidates[i].weight)
				<< "%, Rating: " << candidates[i].rating << ")" << endl;
		}
		//cleaning up memory again 
		delete[] candidates;
	}
	~Graph() {
		cout << "\033[1;31mDeleting graph...\033[0m" << endl;
		delete[] adj;
	}
};