#ifndef HASH_H
#define HASH_H
#include "movie_node.h"
#include "actorNode.h"


//in hash we need to store actor
class hashTableForActors {
    int tableSize;
    actorNode** hashArray;
public:
    bool exists(const string& name, movieNode* movie) {
        //this function prevents from a movie repeating for an actor, genre, or 
       //basically it checks if the movie EXISTS FORONE ACTOR/GENRE OR YEAR 
        int hashVal = hashFunc(name);
        //check if in that hash the movie already exists it
        actorNode* temp = hashArray[hashVal];
        while (temp != nullptr) {
            if (temp->actorName == name) {
                //check their movies
                movieNode* temp2 = temp->moviesOfActor.search(movie->getMovieName());
                if (temp2 == nullptr){
                    return false; //doesnt exist
                }
                return true; //does exist for that specific actor 
                //movies of actor are in a tree

            }
            temp = temp->next;

        }
        return false; //that actor doesnt exist 
    }
    hashTableForActors() {
        //cout << "Creating hash table for actors: " << endl;
        tableSize = 7507; //prime hashing to lessen number of collisions 
        hashArray = new actorNode * [tableSize]();
        for (int i = 0; i < tableSize; i++) {
            hashArray[i] = nullptr;
        }
    }
    int hashFunc(string data) {
        //recieves either actor name or genre and retuns a hash value for it 
        int length = data.size();
        int hashVal = length % tableSize;
        return hashVal;
    }
    void insertInHash(const string& name, movieNode* movie) {
        //recieves weither actor node, or normal node for a linked along witht the movie nod e
        //function inserts value in hash 
        if (exists(name, movie)) return;//if it exists dont ass it 
        int hashVal = hashFunc(name);
        if (hashArray[hashVal] == nullptr) {
            //cout << "Creting new node for actor!" << endl;
            hashArray[hashVal] = new actorNode(name);
            //for this certain actor we append the movie 
            hashArray[hashVal]->addMovie(movie);
            return;
        }
        //basically if its the same actor -> we need to append the movie node to their name
        //and if its the same genre-> we also need to append the movie node to that name
        //for handling genre information we require a genre node, where we have the genre name and the list of movies belonging to that genre  
        //else if collision then we append it to next
        actorNode* temp = hashArray[hashVal];
        while (temp->next != nullptr) {
            if (temp->actorName == name) {
                temp->addMovie(movie);
                return;
            }
            temp = temp->next;
        }
        temp->next = new actorNode(name);
        //cout << "Inserting movie at end..." << endl;
        temp->next->addMovie(movie);
        //cout << "Insertion done for movie.." << endl;
        return;

    }
    void deleteFromHash(string data) {
        //this function deletes value from hash 
        //deletes by value 
    }
    actorNode* search(string const& name) {
        //function searches up a value from hash and returns 
        int hashVal = hashFunc(name);
        if (hashArray[hashVal] == nullptr) {
            //cout << "This actor does not exist in the database." << endl;
            return nullptr;
        }
        else {
            actorNode* ats = hashArray[hashVal];
            while (ats != nullptr && ats->actorName != name)
                ats = ats->next;
            if (ats == nullptr) {
                //cout << "This actor does not exist in the database" << endl;
                return nullptr;
            }
            //cout << "Actor Details: " << endl;
            //ats->display();
            return ats;
        }
    }
    moviesTree getMoviesForKey(string key) {
        //retuens alll the movies an actor has acted in 
        actorNode* getKeyFor = search(key);
        return getKeyFor->moviesOfActor;
    }
    void display() {
        //displays full hash->using it for debugging purposes
        for (int i = 0; i < tableSize; i++) {
            if (hashArray[i] == nullptr) continue;
            actorNode* temp = hashArray[i];
            while (temp != nullptr) {
                //cout << temp->actorName << endl;
                //displaying all movies the avtors have been in 
                //temp->display();
                temp = temp->next;
            }
        }
    }
    ~hashTableForActors() {
        cout << "\033[1;31mDeleting Actor Hash...\033[0m" << endl;
        delete[] hashArray;
    }
};

class genreNode {
public:
    string genreName;
    moviesTree moviesOfThatGenre;
    genreNode* next; //for hashing 
    genreNode() {}
    genreNode(string genreName) {
        this->genreName = genreName;
        next = nullptr;
    }
    void display() {
        //cout << "Displaying all movies belonging to genre: " << genreName << endl;
        //MOVIES OF THAT GENRE IS A LINKED LIST SO WE NEED TO CHEKC THAT FOR A CLEANER DISPLAY 
        moviesOfThatGenre.display();
    }
    //void addMovie(movieNode* movie);
    void addMovie(movieNode* movie) {
        this->moviesOfThatGenre.insert(movie);
        //movie->getMovieName();
    }
};
class hashTableForGenres {
    int tableSize;
    genreNode** hashArray;
public:
    bool exists(const string& name, movieNode* movie) {
        //this function prevents from a movie repeating for an actor, genre, or 
       //basically it checks if the movie EXISTS FORONE ACTOR/GENRE OR YEAR 
        int hashVal = hashFunc(name);
        //check if in that hash the movie already exists it
        genreNode* temp = hashArray[hashVal];
        while (temp != nullptr) {
            if (temp->genreName == name) {
                //check their movies
                movieNode* temp2 = temp->moviesOfThatGenre.search(movie->getMovieName());
                if (temp2 == nullptr) return false; //doesnt exist
                return true; //does exist for that specific actor 
                //movies of actor are in a tree

            }
            temp = temp->next;

        }
        return false; //that actor doesnt exist 
    }
    hashTableForGenres() {
        cout << "Create hash table for genres: " << endl;
        tableSize = 7507; //prime hashing to lessen number of collisions 
        hashArray = new genreNode * [tableSize]();
        for (int i = 0; i < tableSize; i++) {
            hashArray[i] = nullptr;
        }
    }
    int hashFunc(string data) {
        //recieves either actor name or genre and retuns a hash value for it 
        int length = data.size();
        int hashVal = length % tableSize;
        return hashVal;
    }
    void insertInHash(const string& genreName, movieNode* movieName) {
        //recieves weither actor node, or normal node for a linked along witht the movie nod e
        //function inserts value in hash 
        if (exists(genreName, movieName)) return;
        int hashVal = hashFunc(genreName);
        if (hashArray[hashVal] == nullptr) {
            hashArray[hashVal] = new genreNode(genreName);
            //for this certain actor we append the movie 
            hashArray[hashVal]->addMovie(movieName);
            return;
        }
        //basically if its the same actor -> we need to append the movie node to their name
        //and if its the same genre-> we also need to append the movie node to that name
        //for handling genre information we require a genre node, where we have the genre name and the list of movies belonging to that genre  
        //else if collision then we append it to next
        genreNode* temp = hashArray[hashVal];
        while (temp->next != nullptr) {
            if (temp->genreName == genreName) {
                temp->addMovie(movieName);
                return;
            }
            temp = temp->next;
        }
        temp->next = new genreNode(genreName);
        temp->next->addMovie(movieName);
        //cout << "Insertion done for genre.." << endl;//debugging 
        return;

    }
    void deleteFromHash(string data) {
        //this function deletes value from hash 
        //deletes by value 
    }
    genreNode* search(string const& genreName) {
        //function searches up a value from hash and returns 
        int hashVal = hashFunc(genreName);
        if (hashArray[hashVal] == nullptr) {
            cout << "This actor does not exist in the database." << endl;
            return nullptr;
        }
        else {
            genreNode* gts = hashArray[hashVal];
            while (gts != nullptr && gts->genreName != genreName)
                gts = gts->next;
            if (gts == nullptr) {
                cout << "This genere does not exist in the database" << endl;
                return nullptr;
            }
            //CRASHING HERE WE HTHINKS
            //cout << "Genre Details: " << endl;
            //gts->display();
            return gts;
        }
    }
    void genreDetails(string const& genreName) {
        //displays details
        //problem is that its displaying in a really messy manner
        //and mY TEAMMATER ISNT RESPONDIGN
        int hashVal = hashFunc(genreName);
        if (hashArray[hashVal] == nullptr) {
            cout << "This actor does not exist in the database." << endl;
            return;
        }
        else {
            genreNode* gts = hashArray[hashVal];
            while (gts != nullptr && gts->genreName != genreName){
                gts = gts->next;
            }
            if (gts == nullptr) {
                cout << "This genere does not exist in the database" << endl;
                return;
            }
            //CRASHING HERE WE HTHINKS
            //cout << "Genre Details: " << endl;
            gts->display();
            return;
        }
    }
    moviesTree getMoviesForKey(string key) {
        //retuens alll the movies of that genre
        genreNode* getKeyFor = search(key);
        return getKeyFor->moviesOfThatGenre;
    }
    void display() {
        //displays full hash->using it for debugging purpose
        cout << "Displaying movies of that genre: " << endl;
        for (int i = 0; i < tableSize; i++) {
            if (hashArray[i] == nullptr) continue;
            genreNode* temp = hashArray[i];
            while (temp != nullptr) {
                cout << temp->genreName << endl;
                //displaying all movies OF THAT GENRE 
                temp->display();
                temp = temp->next;
            }
        }
    }
    ~hashTableForGenres() {
        cout << "\033[1;31mDeleting Genre Hash\033[0m" << endl;
        delete[] hashArray;
    }
};
class yearNode {
public:
    int releaseYear;
    moviesTree moviesForYear;
    yearNode* next;
    yearNode() {
        releaseYear = 0;
        next = nullptr;
    }
    yearNode(int year) {
        releaseYear = year;
        next = nullptr;
    }
    void addMovie(movieNode* movie) {
        movieNode* copy = new movieNode(*movie);
        moviesForYear.insert(copy);
    }
    void display() {
        cout << "All movies for year: " << releaseYear << endl;
        moviesForYear.display();
    }
};

class hashTableForYears {
    int tableSize;
    yearNode** hashArray;
public:
    hashTableForYears() {
        tableSize = 4099; // prime sized table for integer keys
        hashArray = new yearNode * [tableSize]();
        for (int i = 0; i < tableSize; i++) {
            hashArray[i] = nullptr;
        }
    }
    bool exists(int year, movieNode* movie) {
        //this function prevents from a movie repeating for an actor, genre, or 
       //basically it checks if the movie EXISTS FORONE ACTOR/GENRE OR YEAR 
        int hashVal = hashFunc(year);
        //check if in that hash the movie already exists it
        yearNode* temp = hashArray[hashVal];
        while (temp != nullptr) {
            if (temp->releaseYear == year) {
                //check their movies
                movieNode* temp2 = temp->moviesForYear.search(movie->getMovieName());
                if (temp2 == nullptr) return false; //doesnt exist
                return true; //does exist for that specific actor 
                //movies of actor are in a tree

            }
            temp = temp->next;

        }
        return false; //that actor doesnt exist 
    }
    int hashFunc(int year) {
        if (year < 0) {
            year = -year;
        }
        return year % tableSize;
    }
    void insertInHash(int year, movieNode* movie) {
        if (exists(year, movie))return;
        int hashVal = hashFunc(year);
        if (hashArray[hashVal] == nullptr) {
            hashArray[hashVal] = new yearNode(year);
            hashArray[hashVal]->addMovie(movie);
            return;
        }
        yearNode* temp = hashArray[hashVal];
        while (temp != nullptr) {
            if (temp->releaseYear == year) {
                temp->addMovie(movie);
                return;
            }
            if (temp->next == nullptr) {
                break;
            }
            temp = temp->next;
        }
        temp->next = new yearNode(year);
        temp->next->addMovie(movie);
    }
    yearNode* search(int year) {
        int hashVal = hashFunc(year);
        if (hashArray[hashVal] == nullptr) {
            cout << "This year does not exist in the database." << endl;
            return nullptr;
        }
        yearNode* yts = hashArray[hashVal];
        while (yts != nullptr && yts->releaseYear != year) {
            yts = yts->next;
        }
        if (yts == nullptr) {
            cout << "This year does not exist in the database." << endl;
            return nullptr;
        }
        cout << "Movies released in " << year << ":" << endl;
        yts->display();
        return yts;
    }
    ~hashTableForYears() {
        cout << "\033[1;31mDeleting Hash Table for Years...\033[0m" << endl;
        delete[] hashArray;
    }
};

// rating based AVL tree to support range search
struct ratingMovieNode {
    movieNode* movie;
    ratingMovieNode* next;
    ratingMovieNode(movieNode* m) {
        movie = m;
        next = nullptr;
    }
};

class ratingNode {
public:
    double rating;
    int height;
    ratingNode* left;
    ratingNode* right;
    ratingMovieNode* moviesHead;
    ratingNode(double ratingVal) {
        rating = ratingVal;
        height = 0;
        left = nullptr;
        right = nullptr;
        moviesHead = nullptr;
    }
    void addMovie(movieNode* movie) {
        ratingMovieNode* newNode = new ratingMovieNode(movie);
        if (moviesHead == nullptr) {
            moviesHead = newNode;
            return;
        }
        ratingMovieNode* temp = moviesHead;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
    void displayMovies() {
        const string COLOR_RED = "\033[91m";
        const string COLOR_RESET = "\033[0m";
        ratingMovieNode* temp = moviesHead;
        while (temp != nullptr) {
            temp->movie->display();
            cout << endl;
            temp = temp->next;
        }
    }
};


//for rating we are implementinf an avl tree while the rest seatrchings are getting hashing 
class ratingTree {
private:
    ratingNode* root;
    int returnHeight(ratingNode* node) {
        if (node == nullptr) {
            return -1;
        }
        int leftHeight = returnHeight(node->left);
        int rightHeight = returnHeight(node->right);
        int bigger = 0;
        if (leftHeight > rightHeight) {
            bigger = leftHeight;
        }
        else {
            bigger = rightHeight;
        }
        return bigger + 1;
    }
    ratingNode* rotateLeft(ratingNode* K2) {
        ratingNode* K1 = K2->right;
        K2->right = K1->left;
        K1->left = K2;
        K2->height = max(returnHeight(K2->left), returnHeight(K2->right)) + 1;
        K1->height = max(returnHeight(K1->left), returnHeight(K1->right)) + 1;
        return K1;
    }
    ratingNode* rotateRight(ratingNode* K2) {
        ratingNode* K1 = K2->left;
        K2->left = K1->right;
        K1->right = K2;
        K2->height = max(returnHeight(K2->left), returnHeight(K2->right)) + 1;
        K1->height = max(returnHeight(K1->left), returnHeight(K1->right)) + 1;
        return K1;
    }
    ratingNode* insertNode(ratingNode* current, double rating, movieNode* movie) {
        if (current == nullptr) {
            ratingNode* newNode = new ratingNode(rating);
            newNode->addMovie(movie);
            return newNode;
        }
        if (rating < current->rating) {
            current->left = insertNode(current->left, rating, movie);
        }
        else if (rating > current->rating) {
            current->right = insertNode(current->right, rating, movie);
        }
        else {
            current->addMovie(movie);
            return current;
        }
        current->height = max(returnHeight(current->left), returnHeight(current->right)) + 1;
        int balance = returnHeight(current->left) - returnHeight(current->right);
        if (balance > 1 && rating < current->left->rating) {
            return rotateRight(current);
        }
        if (balance < -1 && rating > current->right->rating) {
            return rotateLeft(current);
        }
        if (balance > 1 && rating > current->left->rating) {
            current->left = rotateLeft(current->left);
            return rotateRight(current);
        }
        if (balance < -1 && rating < current->right->rating) {
            current->right = rotateRight(current->right);
            return rotateLeft(current);
        }
        return current;
    }
    void searchRangeInternal(ratingNode* current, double low, double high) {
        if (current == nullptr) {
            return;
        }
        if (current->rating > low) {
            searchRangeInternal(current->left, low, high);
        }
        if (current->rating >= low && current->rating <= high) {
            current->displayMovies();
        }
        if (current->rating < high) {
            searchRangeInternal(current->right, low, high);
        }
    }
public:
    ratingTree() {
        root = nullptr;
    }
    void insert(double rating, movieNode* movie) {
        root = insertNode(root, rating, movie);
    }
    void searchRange(double low, double high) {
        cout << "Movies with rating between " << low << " and " << high << ":" << endl;
        searchRangeInternal(root, low, high);
    }
};
#endif 