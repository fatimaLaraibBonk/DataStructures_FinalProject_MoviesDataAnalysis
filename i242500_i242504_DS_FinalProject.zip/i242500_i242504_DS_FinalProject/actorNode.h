#ifndef ACTORNODE_H
#define ACTORNODE_H
#include <iostream>
#include "linkedList.h"
#include "movie_node.h"
using namespace std;

class actorNode {
public:
	//data needeed
	string actorName;
	moviesTree moviesOfActor; //stores those movies that the actor has acted in in a linked list 
	//now initially we are planning to store actors in a hash table 
	//so we need a next pointer
	actorNode* next;
	actorNode(){}
	actorNode(string name) {
		actorName = name;
		next = nullptr;
	}
	void addMovie(movieNode* movie); //this function receives movies that the actor has acted on		
	void display(); //display the actors name along with the movies they have acted in 
	void displayActorDetails(); //display actor name, movies, and co-actors
	void displayCoactors() {
		//we need to go through all the movies the actor has been in i.e. moviesOfActor
		
	}
};
//actor node header class
#endif
