#include "actorNode.h"
using namespace std;

//actorNode cpp file

// Color codes for beautiful output
const string COLOR_RESET = "\033[0m";
const string COLOR_PINK = "\033[95m";
const string COLOR_BLUE = "\033[94m";
const string COLOR_GREEN = "\033[92m";
const string COLOR_CYAN = "\033[96m";
const string COLOR_MAGENTA = "\033[35m";
const string COLOR_YELLOW = "\033[93m";

void actorNode::addMovie(movieNode* movie) {
	//adds movie to the movie node tree
	//movie insertion is not wokring 
	this->moviesOfActor.insert(movie); //this part inserts the movie in the tree 
	//cout << "Movie added for " << actorName << ": ";
	//movie->getMovieName();
	//cout << endl;
}
void actorNode::display() {
	//displays movies for that actor 
	cout << "The actor has been in the following movies: " << actorName << ": ";
	moviesOfActor.display();
}

void actorNode::displayActorDetails() {
	cout << COLOR_MAGENTA << "\n╔════════════════════════════════════════════════╗" << COLOR_RESET << endl;
	cout << COLOR_MAGENTA << "║" << COLOR_PINK << "           ACTOR DETAILS" << COLOR_MAGENTA << "                    ║" << COLOR_RESET << endl;
	cout << COLOR_MAGENTA << "╚════════════════════════════════════════════════╝" << COLOR_RESET << endl;
	
	// Display actor name
	cout << COLOR_CYAN << "\n🎭 Actor Name: " << COLOR_YELLOW << actorName << COLOR_RESET << endl;
	cout << COLOR_MAGENTA << "────────────────────────────────────────────────" << COLOR_RESET << endl;
	
	// Collect all movies and co-actors
	movieNode* root = moviesOfActor.getHead();
	if (!root) {
		cout << COLOR_PINK << "No movies found for this actor." << COLOR_RESET << endl;
		return;
	}
	
	// Collect all movies using iterative traversal
	movieNode* movieStack[500];
	int stackTop = 0;
	movieNode* current = root;
	int movieCount = 0;
	movieNode* movies[500];
	
	// Collect movies
	while (current != nullptr || stackTop > 0) {
		while (current != nullptr && stackTop < 500) {
			movieStack[stackTop++] = current;
			current = current->left;
		}
		if (stackTop > 0) {
			current = movieStack[--stackTop];
			movies[movieCount++] = current;
			current = current->right;
		}
	}
	
	// Display movies
	cout << COLOR_GREEN << "\n📽️  Movies (" << movieCount << "):" << COLOR_RESET << endl;
	for (int i = 0; i < movieCount; i++) {
		cout << COLOR_BLUE << "   " << (i + 1) << ". " << COLOR_RESET << movies[i]->movieName;
		cout << COLOR_CYAN << " (Rating: " << movies[i]->rating << ", Year: " << movies[i]->releaseYear << ")" << COLOR_RESET << endl;
	}
	
	// Collect all co-actors (actors from all movies, excluding the current actor)
	string coActorNames[2000];
	bool coActorAdded[2000];
	int coActorCount = 0;
	
	// Initialize coActorAdded array
	for (int i = 0; i < 2000; i++) {
		coActorAdded[i] = false;
	}
	
	// Go through all movies and collect co-actors
	for (int i = 0; i < movieCount; i++) {
		node* actorNode = movies[i]->actorsList.getHead();
		if (!actorNode) continue;
		
		node* startActor = actorNode;
		do {
			string coActorName = actorNode->getData();
			
			// Skip if it's the same actor
			if (coActorName == actorName) {
				actorNode = actorNode->getNext();
				continue;
			}
			
			// Check if already added
			bool found = false;
			for (int j = 0; j < coActorCount; j++) {
				if (coActorNames[j] == coActorName) {
					found = true;
					break;
				}
			}
			
			// Add if not found
			if (!found && coActorCount < 2000) {
				coActorNames[coActorCount++] = coActorName;
			}
			
			actorNode = actorNode->getNext();
		} while (actorNode != startActor);
	}
	
	// Display co-actors
	cout << COLOR_GREEN << "\n👥 Co-Actors (" << coActorCount << "):" << COLOR_RESET << endl;
	if (coActorCount == 0) {
		cout << COLOR_PINK << "   No co-actors found." << COLOR_RESET << endl;
	} else {
		for (int i = 0; i < coActorCount; i++) {
			cout << COLOR_BLUE << "   " << (i + 1) << ". " << COLOR_RESET << coActorNames[i] << endl;
		}
	}
	
	cout << COLOR_MAGENTA << "\n────────────────────────────────────────────────" << COLOR_RESET << endl;
	cout << endl;
}

