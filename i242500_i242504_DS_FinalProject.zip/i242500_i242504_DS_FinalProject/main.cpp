#include <iostream>
#include <ctime>
#include "CSV_operations.h"
#include "linkedList.h"

using namespace std;

//COMPLETE MENU 
//WITH PRETTY COLORS
//BY FATIMA LARAIB AMND HUZAIFARAHMAN

// Color codes for beautiful terminal output
const string COLOR_RESET = "\033[0m";
const string COLOR_PINK = "\033[95m";
const string COLOR_BLUE = "\033[94m";
const string COLOR_GREEN = "\033[92m";
const string COLOR_CYAN = "\033[96m";
const string COLOR_MAGENTA = "\033[35m";
const string COLOR_YELLOW = "\033[93m";
const string COLOR_BRIGHT_BLUE = "\033[94m";
const string COLOR_BRIGHT_GREEN = "\033[92m";
const string COLOR_RED = "\033[91m"; 
string toLower2(std::string str) {
    for (int i = 0; i < str.length(); i++) {
        if (str[i] >= 'A' && str[i] <= 'Z') {
            str[i] = str[i] + 32; 
            //converting to lower case to prevent movie clases
        }
    }
    return str;
}
int main() {
    reader r;
    r.read_file();

    int choice;
    string input;
    double lowRating, highRating;
    int year;
    cout << COLOR_CYAN << "Creating graph edges..." << COLOR_RESET << endl;
    clock_t start = clock();
    r.moviesGraph.createEdges(r.hashTabA, r.hashTabG); //creating edges 
    clock_t end = clock();
    double timeTaken = ((double)(end - start)) / CLOCKS_PER_SEC;
    cout << COLOR_GREEN << " Graph edges created in " << COLOR_YELLOW << timeTaken << COLOR_GREEN << " seconds" << COLOR_RESET << endl;
    cout << COLOR_CYAN << "Starting loop: " << COLOR_RESET << endl;
    while (true) {
        cout << COLOR_MAGENTA << "\n╔════════════════════════════════════╗" << COLOR_RESET << endl;
        cout << COLOR_MAGENTA << "║" << COLOR_PINK << "        Movie Search System        " << COLOR_MAGENTA << "║" << COLOR_RESET << endl;
        cout << COLOR_MAGENTA << "╚════════════════════════════════════╝" << COLOR_RESET << endl;
        cout << COLOR_CYAN << " 1. " << COLOR_YELLOW << "Search by Movie Title" << COLOR_RESET << endl;
        cout << COLOR_CYAN << " 2. " << COLOR_YELLOW << "Search by Actor Name" << COLOR_RESET << endl;
        cout << COLOR_CYAN << " 3. " << COLOR_YELLOW << "Search by Genre" << COLOR_RESET << endl;
        cout << COLOR_CYAN << " 4. " << COLOR_YELLOW << "Search by Year" << COLOR_RESET << endl;
        cout << COLOR_CYAN << " 5. " << COLOR_YELLOW << "Search by Rating Range" << COLOR_RESET << endl;
        cout << COLOR_CYAN << " 6. " << COLOR_YELLOW << "Get Recommendations for a movie" << COLOR_RESET << endl;
        cout << COLOR_CYAN << " 7. " << COLOR_YELLOW << "Find shortest path between two movies" << COLOR_RESET << endl;
        cout << COLOR_CYAN << " 8. " << COLOR_YELLOW << "Exit" << COLOR_RESET << endl;
        cout << COLOR_GREEN << "Enter your choice: " << COLOR_RESET;
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            cout << COLOR_YELLOW << "Enter movie title: " << COLOR_RESET;
            getline(cin, input);
            input = toLower2(input);
            clock_t start = clock();
            r.moviesT.displayDetailsOfMovie(input); //done should be properly wokring 
            clock_t end = clock();
            double timeTaken = ((double)(end - start)) / CLOCKS_PER_SEC;
            cout << COLOR_CYAN << "\n⏱️  Operation completed in " << COLOR_GREEN << timeTaken << COLOR_CYAN << " seconds" << COLOR_RESET << endl;
        }
        else if (choice == 2) {
            cout << COLOR_YELLOW << "Enter actor name: " << COLOR_RESET;
            getline(cin, input);
            input = toLower2(input);
            clock_t start = clock();
            actorNode* actor = r.hashTabA.search(input);
            if (actor != nullptr) {
                actor->displayActorDetails();
            } else {
                cout << COLOR_PINK << "Actor '" << input << "' not found in database!" << COLOR_RESET << endl;
            }
            clock_t end = clock();
            double timeTaken = ((double)(end - start)) / CLOCKS_PER_SEC;
            cout << COLOR_CYAN << "\n⏱️  Operation completed in " << COLOR_GREEN << timeTaken << COLOR_CYAN << " seconds" << COLOR_RESET << endl;
        }
        else if (choice == 3) {
            cout << COLOR_YELLOW << "Enter genre: " << COLOR_RESET;
            getline(cin, input);
            input = toLower2(input);
            clock_t start = clock();
            r.hashTabG.genreDetails(input); //SHOULD BE WORKING IF IT DOESNT THEN 
            clock_t end = clock();
            double timeTaken = ((double)(end - start)) / CLOCKS_PER_SEC;
            cout << COLOR_CYAN << "\n⏱️  Operation completed in " << COLOR_GREEN << timeTaken << COLOR_CYAN << " seconds" << COLOR_RESET << endl;
        }
        else if (choice == 4) {
            cout << COLOR_YELLOW << "Enter year: " << COLOR_RESET;
            cin >> year;
            cin.ignore();
            clock_t start = clock();
            r.hashTabY.search(year); //SHOULD BE WOTRKING 
            clock_t end = clock();
            double timeTaken = ((double)(end - start)) / CLOCKS_PER_SEC;
            cout << COLOR_CYAN << "\n⏱️  Operation completed in " << COLOR_GREEN << timeTaken << COLOR_CYAN << " seconds" << COLOR_RESET << endl;
        }
        else if (choice == 5) {
            cout << COLOR_YELLOW << "Enter minimum rating: " << COLOR_RESET;
            cin >> lowRating;
            cout << COLOR_YELLOW << "Enter maximum rating: " << COLOR_RESET;
            cin >> highRating;
            cin.ignore();
            clock_t start = clock();
            r.ratingT.searchRange(lowRating, highRating); //SHOULF BE WORKING 
            clock_t end = clock();
            double timeTaken = ((double)(end - start)) / CLOCKS_PER_SEC;
            cout << COLOR_CYAN << "\n⏱️  Operation completed in " << COLOR_GREEN << timeTaken << COLOR_CYAN << " seconds" << COLOR_RESET << endl;
        }
        else if (choice == 6) {
            cout << COLOR_YELLOW << "Enter movie name: " << COLOR_RESET;
            getline(cin, input);
            input = toLower2(input);
            clock_t start = clock();
            r.moviesGraph.getRecommendations(input, r.ratingT); //WORKING 
            clock_t end = clock();
            double timeTaken = ((double)(end - start)) / CLOCKS_PER_SEC;
            cout << COLOR_CYAN << "\n⏱️  Operation completed in " << COLOR_GREEN << timeTaken << COLOR_CYAN << " seconds" << COLOR_RESET << endl;
        }
        else if (choice == 7) {
            cout << COLOR_YELLOW << "Enter movie name 1: " << COLOR_RESET;
            getline(cin, input);
            input = toLower2(input);
            cout << COLOR_YELLOW << "Enter movie name 2: " << COLOR_RESET;
            string input2;
            getline(cin, input2);
            input2 = toLower2(input2);
            clock_t start = clock();
            r.moviesGraph.findShortestPath(input, input2);
            clock_t end = clock();
            double timeTaken = ((double)(end - start)) / CLOCKS_PER_SEC;
            cout << COLOR_CYAN << "\n⏱️  Operation completed in " << COLOR_GREEN << timeTaken << COLOR_CYAN << " seconds" << COLOR_RESET << endl;
        }
        else if (choice == 8) {
            cout << COLOR_CYAN << "Exiting..." << COLOR_RESET << endl;
            break;
        }
        else {
            cout << COLOR_PINK << "Invalid choice. Please try again." << COLOR_RESET << endl;
        }
    }
    return 0;
}
