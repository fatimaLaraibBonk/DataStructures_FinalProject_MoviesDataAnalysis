#include "movie_node.h"

movieNode::movieNode(string name, string directorName, linkedList actorsList, linkedList genresList, double rating, int releaseYear){
    this->movieName=name;
    this->directorName=directorName;
    this->actorsList=actorsList;
    this->genresList=genresList;
    this->rating=rating;
    this->releaseYear=releaseYear;
    this->height = 0;
    this->left=nullptr;
    this->right=nullptr;
    edges = nullptr;
    visitedForEdges = false;
}
void movieNode::display(){
    const string COLOR_RED = "\033[91m";
    const string COLOR_RESET = "\033[0m";
    const string COLOR_CYAN = "\033[96m";
    const string COLOR_YELLOW = "\033[93m";
    cout << COLOR_CYAN << "Displaying Movie Information: " << COLOR_RESET << endl;
    cout << COLOR_YELLOW << "Name: " << COLOR_RESET << COLOR_RED << this->movieName << COLOR_RESET << endl;
    cout << COLOR_YELLOW << "Director's name: " << COLOR_RESET << this->directorName << endl;
    cout << COLOR_YELLOW << "Actors Involved: " << COLOR_RESET << endl;
    this->actorsList.display();
    cout << COLOR_YELLOW << "Genres: " << COLOR_RESET << endl;
    this->genresList.display();
    cout << COLOR_YELLOW << "Rating: " << COLOR_RESET << this->rating << endl;
    cout << COLOR_YELLOW << "Release Year: " << COLOR_RESET << this->releaseYear << endl;
}